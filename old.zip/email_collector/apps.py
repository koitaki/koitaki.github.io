from django.apps import AppConfig


class BasicSignupConfig(AppConfig):
    name = 'basic_signup'
